package serviceprofile

// GroupName identifies the API Group Name for a ServiceProfile.
const GroupName = "linkerd.io"
