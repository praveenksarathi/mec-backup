// +k8s:deepcopy-gen=package
// +groupName=linkerd.io

package v1alpha1
