---
name: 🙋🏾 Question
about: If you have a ❓, please check out our Slack or Discourse!

---

--------------^ Click "Preview" for a better view!

We primarily use GitHub as an issue tracker. For any questions you may have,
please check out the resources below.

---

- Mailing List: https://lists.cncf.io/g/cncf-linkerd-users

- Slack: https://slack.linkerd.io

- Discourse: https://discourse.linkerd.io/

- Twitter: https://twitter.com/linkerd
