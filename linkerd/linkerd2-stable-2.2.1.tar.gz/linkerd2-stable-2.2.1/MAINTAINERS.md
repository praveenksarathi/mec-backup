The Linkerd2 maintainers are:

* Oliver Gould <ver@buoyant.io> @olix0r (super-maintainer)
* Kevin Lingerfelt <kl@buoyant.io> @klingerf (super-maintainer)
* Risha Mars <mars@buoyant.io> @rmars
* Brian Smith <brian@buoyant.io> @briansmith
* Andrew Seigner <siggy@buoyant.io> @siggy

<!--
# Adding a new maintainer

* Submit a PR modifying this file
* Add maintainer to .github/CODEOWNERS
* Obtain approvals per GOVERNANCE.md
* Invite maintainer to https://github.com/orgs/linkerd/teams/linkerd2-maintainers/members
* Invite maintainer to https://github.com/orgs/linkerd/people
-->
